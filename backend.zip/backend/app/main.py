from fastapi import FastAPI

from app.api.users import router as users_router
from app.api.accounts import router as accounts_router
from app.api.transactions import router as transactions_router
from app.api.auth import router as auth_router

app = FastAPI()

app.include_router(users_router)
app.include_router(accounts_router)
app.include_router(transactions_router)
app.include_router(auth_router)